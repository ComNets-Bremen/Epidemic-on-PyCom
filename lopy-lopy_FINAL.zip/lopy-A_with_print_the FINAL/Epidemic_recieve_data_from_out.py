import time
import common
import utime

#recieved_data_buffer = []

def Time_conversion(seconds):
    seconds = seconds % (24 * 3600)
    hour = seconds // 3600
    seconds %= 3600
    minutes = seconds // 60
    seconds %= 60

    return ("%d:%02d:%02d" % (hour, minutes, seconds))

def rxred_data():
    while True:
        with common.common_var.lock_LoRa_ND:
            if len(common.common_var.time_list) >0:
                tt =utime.localtime()
                current_time1=utime.mktime(tt)
                sync_time = str(int(current_time1) - int(common.common_var.difference))
                sync_time1=int(sync_time)
                #common.print_str('recieved data: {0} {1}'.format(common.common_var.Rxr_data, common.common_var.sync_time))
                if len(common.common_var.Rxr_data)>0:
                    #common.print_str("{0}  {1}  Epedemic  D  received Data {2}".format(Time_conversion(sync_time1),common.common_var.str_add, common.common_var.Rxr_data.decode("utf-8")))
                    #common.print_str('received data {0}-------{1}'.format(common.common_var.Rxr_data.decode("utf-8"), sync_time))
                    rxr_data_split=common.common_var.Rxr_data.decode("utf-8").split(':')
                    if str(rxr_data_split[2]) == common.common_var.str_add:
                        common.print_str("{0}  {1}  Epedemic  D  received Data {2}".format(Time_conversion(sync_time1),common.common_var.str_add, common.common_var.Rxr_data.decode("utf-8")))
                        relevant_data= str(rxr_data_split[-1])
                        pair=relevant_data.split('-')
                        to_store={pair[-1]:pair[0]}
                        common.common_var.generated_data_buffer.update(to_store)
                        flag1 = str(rxr_data_split[3])
                        flag2 = str(rxr_data_split[4])
                        adress_of_sender = str(rxr_data_split[1])
                        if flag2 == 'L':
                            if flag1 == 'FS':
                                new_flag = 'RF'
                                common.print_str("{0}  {1}  Epedemic  S  Starting to send reply as SV to {2}".format(Time_conversion(sync_time1),common.common_var.str_add,adress_of_sender))
                                #common.print_str('starting to send reply as SV--------{}'.format(sync_time))
                                index_list=list(common.common_var.generated_data_buffer.keys())
                                SV_string1='-'.join(index_list)
                                common.common_var.SV_packet1 = "SV"+":"+common.common_var.str_add+":"+adress_of_sender+":"+new_flag+":"+"N"+":"+"N"+":"+SV_string1
                            elif flag1=='RF':

                                common.common_var.Served_list.append(adress_of_sender)
                                
                                common.print_str("{0}  {1}  Epedemic     End of anti-entropy session with {2}".format(Time_conversion(sync_time1),common.common_var.str_add,adress_of_sender))
                                #$common.print_str('{0} End of anti-entropy session'.format(Time_conversion(sync_time1)))
                                # end of anti entophy and adding to served list
                            else:
                                pass
                        else:
                            pass

                    else:
                        pass

                else:
                    pass
                common.common_var.Rxr_data=''
            else:
                print('synching in progress')
            common.common_var.lock_LoRa_ND.release()
            time.sleep(6)
