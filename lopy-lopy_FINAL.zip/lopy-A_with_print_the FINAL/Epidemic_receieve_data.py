import time
import common
import utime

common.common_var.generated_data_buffer = {}

#script.className.variablename = dosomething
def buffer_generated_data():
    while True:
        with common.common_var.lock_LoRa_ND:
            if len(common.common_var.time_list) >0:
                generated_data = common.common_var.string_sent_to_epidemic
                splitted_data = generated_data.split(':')
                #print(splitted_data)
                raw_data = splitted_data[0]
                data_index = splitted_data[-1]
                final_data={data_index:raw_data}
                if len(common.common_var.generated_data_buffer) < 1:
                    if len(raw_data) >0:
                        common.common_var.generated_data_buffer.update(final_data)
                        #print(common.common_var.generated_data_buffer)
                        #print("len of buffer:{}".format(len(common.common_var.generated_data_buffer)))
                    else:
                        pass
                else:
                    pass
            else:
                print('synching in progress')
            common.common_var.lock_LoRa_ND.release()
            time.sleep(10)
