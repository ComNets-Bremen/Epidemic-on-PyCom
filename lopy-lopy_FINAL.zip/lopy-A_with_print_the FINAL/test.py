from machine import RTC
import utime
import common

list=[]
msg='b:time'

if len(list) == 0:
    splt=msg.split(':')
    time1=splt[-1]
    t1=splt[1]
    list.append(time1)
else:
    pass
