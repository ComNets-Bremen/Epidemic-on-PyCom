#!/usr/bin/env python
#
# Copyright (c) 2019, Pycom Limited.
#
# This software is licensed under the GNU GPL version 3 or any
# later version, with permitted additional terms. For more information
# see the Pycom Licence v1.0 document supplied with this file, or
# available at https://www.pycom.io/opensource/licensing
#

from network import LoRa
import socket
import time
import ubinascii
import common
import utime

#from teasting1 import msg

lora = LoRa(mode=LoRa.LORA, region=LoRa.EU868)
s = socket.socket(socket.AF_LORA, socket.SOCK_RAW)
s.setblocking(False)


def Time_conversion(seconds):
    seconds = seconds % (24 * 3600)
    hour = seconds // 3600
    seconds %= 3600
    minutes = seconds // 60
    seconds %= 60

    return ("%d:%02d:%02d" % (hour, minutes, seconds))
#create hello message and send out
def Lora_send_hello():
    while True:
        with common.common_var.lock_LoRa_ND:
            if len(common.common_var.time_list) >0:
                hello_packet = "H"+":"+common.common_var.str_add+":"+"N"+":"+"N"+":"+"N"+":"+"N"+":"+"N"
                tt =utime.localtime()
                current_time1=utime.mktime(tt)
                sync_time = str(int(current_time1) - int(common.common_var.difference))
                sync_time1=int(sync_time)
                s.send(hello_packet)
                #common.print_str('sent hello {0}--------{1}'.format(hello_packet, sync_time))
                time.sleep(6)
            else:
                print('synching in progress')
            common.common_var.lock_LoRa_ND.release()

##sending SV recieved from Epidemic_SV_module
def LoRa_send_SV():
    while True:
        with common.common_var.lock_LoRa_ND:
            if len(common.common_var.time_list) >0:
                if len(common.common_var.SV_sending_to_LoRa) >0:
                    SV_split = common.common_var.SV_sending_to_LoRa.split(":")
                    common.common_var.SV_packet= "SV"+":"+common.common_var.str_add+":"+SV_split[0]+":"+"FS"+":"+"N"+":"+"N"+":"+SV_split[-1]
                    if len(SV_split[-1]) > 0:
                        tt =utime.localtime()
                        current_time1=utime.mktime(tt)
                        sync_time = str(int(current_time1) - int(common.common_var.difference))
                        sync_time1=int(sync_time)
                        s.send(common.common_var.SV_packet)
                        common.print_str("{0}  {1}  LoRa      S  sent SV {2}".format(Time_conversion(sync_time1),common.common_var.str_add,common.common_var.SV_packet))
                        #common.print_str('sent SV {0}----------{1}'.format(common.common_var.SV_packet, sync_time))
                        #print("length of sending SV packet is: {}".format(len(SV_packet)))

                    else:
                        pass
                        #print("no MAC selected")

                else:
                    pass
                common.common_var.SV_sending_to_LoRa=''
            else:
                print('synching in progress')
            common.common_var.lock_LoRa_ND.release()
            time.sleep(6)

##send data requests according to compared SV
def LoRa_send_request():
    while True:
        with common.common_var.lock_LoRa_ND:
            if len(common.common_var.time_list) >0:
                tt =utime.localtime()
                current_time1=utime.mktime(tt)
                sync_time = str(int(current_time1) - int(common.common_var.difference))
                sync_time1=int(sync_time)
                if len(common.common_var.sending) > 0:
                    y = common.common_var.sending.split(':')
                    wanted= y[-1].split('-')
                    ####
                    if len(wanted) > 0:
                        count = 0
                        for i in wanted:
                            count += 1
                            if count == len(wanted):
                                common.print_str("{0}  {1}  LoRa         starting to send last request for {2}".format(Time_conversion(sync_time1),common.common_var.str_add,i))
                                #common.print_str('starting to send last request for {0}--------{1}'.format(i,sync_time))
                                request_packet = "R" + ":" + common.common_var.str_add +":"+ y[0] +":"+ y[1] +":"+ "L" +":"+ "N" + ":" + i
                                #common.common_var.wanted = i + ":" + recieved_sv_split[3]+":"+"L"+":"+ recieved_sv_split[1]
                                #print(common.common_var.wanted)
                            else:
                                common.print_str("{0}  {1}  LoRa         starting to send request for {2}".format(Time_conversion(sync_time1),common.common_var.str_add,i))
                                #common.print_str('starting to send request for {0}--------{1}'.format(i,sync_time))
                                request_packet = "R" + ":" + common.common_var.str_add +":"+ y[0] +":"+ y[1] +":"+ "N" +":"+ "N" + ":" + i
                                #common.common_var.wanted = i +":"+ recieved_sv_split[3]+":"+"N"+":"+ recieved_sv_split[1]
                    ####
                            s.send(request_packet)
                            common.print_str("{0}  {1}  LoRa      R  request sent {2}".format(Time_conversion(sync_time1),common.common_var.str_add,request_packet))
                            #common.print_str('request sent {0}---------{1}'.format(request_packet, sync_time))
                    else:
                        #print("no data to send")
                        pass

                else:
                    pass
                common.common_var.sending=''
            else:
                print('synching in progress')
            common.common_var.lock_LoRa_ND.release()
            time.sleep(6)


###send data for the requests recieved
def LoRa_send_data():
    while True:
        with common.common_var.lock_LoRa_ND:
            if len(common.common_var.time_list) >0:
                if len(common.common_var.requested_data) >0:
                    x = common.common_var.requested_data.split(':')
                    Data_packet= "D" + ":" + common.common_var.str_add +":"+ x[-2] +":"+ x[1] +":"+ x[2] +":"+ "N" + ":" + x[0]+"-"+x[-1]
                    if len(x[0]) > 0:
                        tt =utime.localtime()
                        current_time1=utime.mktime(tt)
                        sync_time = str(int(current_time1) - int(common.common_var.difference))
                        sync_time1=int(sync_time)
                        s.send(Data_packet)
                        common.print_str("{0}  {1}  LoRa      D  Data sent {2}".format(Time_conversion(sync_time1),common.common_var.str_add,Data_packet))
                        #common.print_str('data sent {0}------------{1}'.format(Data_packet, sync_time))
                    else:
                        #print("no data to send")
                        pass
                    common.common_var.requested_data=''
                else:
                    pass
            else:
                print('synching in progress')
            common.common_var.lock_LoRa_ND.release()
            time.sleep(6)

###send reply SV
def reply_SV():
    while True:
        with common.common_var.lock_LoRa_ND:
            if len(common.common_var.time_list) >0:
                if len(common.common_var.SV_packet1) >0:
                    tt =utime.localtime()
                    current_time1=utime.mktime(tt)
                    sync_time = str(int(current_time1) - int(common.common_var.difference))
                    sync_time1=int(sync_time)
                    s.send(common.common_var.SV_packet1)
                    common.print_str("{0}  {1}  LoRa      S  reply SV sent {2}".format(Time_conversion(sync_time1),common.common_var.str_add,common.common_var.SV_packet1))
                    #common.print_str('reply SV sent {0}------------{1}'.format(common.common_var.SV_packet1, sync_time))
                else:
                    #print("no data to send")
                    pass
                common.common_var.SV_packet1=''
            else:
                print('synching in progress')
            common.common_var.lock_LoRa_ND.release()
            time.sleep(6)
