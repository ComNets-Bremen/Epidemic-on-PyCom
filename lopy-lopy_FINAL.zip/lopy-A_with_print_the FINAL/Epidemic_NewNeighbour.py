import time
import common
import utime

common.common_var.neighbor_list = {}
def Time_conversion(seconds):
    seconds = seconds % (24 * 3600)
    hour = seconds // 3600
    seconds %= 3600
    minutes = seconds // 60
    seconds %= 60

    return ("%d:%02d:%02d" % (hour, minutes, seconds))


def recieve_new_neighbour():
        while True:
            with common.common_var.lock_LoRa_ND:
                if len(common.common_var.time_list) >0:
                    node = common.common_var.Nd_epi
                    if len(node) >0: #see if only greater than zero works. initialy >= was here
                        node_split = node.split(':')
                        neighbour_MAC = node_split[0]
                        time_stamp = node_split[-1]
                        tt =utime.localtime()
                        current_time1=utime.mktime(tt)
                        sync_time = str(int(current_time1) - int(common.common_var.difference))
                        sync_time1=int(sync_time)

                        if neighbour_MAC in common.common_var.neighbor_list.keys():  #update the time stamp
                            update_time = {neighbour_MAC:time_stamp}
                            common.common_var.neighbor_list.update(update_time)
                            #common.print_str("{0} ".format(Time_conversion(sync_time1)))
                            #common.print_str("{0} {1}  Epedemic_Module  Neighbour list is {2}".format(Time_conversion(sync_time1),common.common_var.str_add,common.common_var.neighbor_list))
                        else: #add neighbour to the dictionary
                            add_list = {neighbour_MAC:time_stamp}
                            common.common_var.neighbor_list.update(add_list)
                            #common.print_str("{0} {1}  Epedemic_Module  Neighbour list is {2}".format(Time_conversion(sync_time1),common.common_var.str_add,common.common_var.neighbor_list))
                            #common.print_str("neighbour list is:{0}-------{1}".format(common.common_var.neighbor_list,sync_time))
                    else:
                        pass
                else:
                    print('synching in progress')
                common.common_var.lock_LoRa_ND.release()
                time.sleep(6)
