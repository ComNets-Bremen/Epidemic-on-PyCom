import ubinascii
import crypto
import utime
import time
import common


#class Application:
def send_data():
    while True:
        with common.common_var.lock_LoRa_ND:
            if len(common.common_var.time_list) >0:
                #generating the data
                x = crypto.getrandbits(4)
                hex_data = ubinascii.hexlify(x) # coversion from hexa decimal
                str_data = hex_data.decode("utf-8") # decoding to string

                #get the EPOCH time: to create an index for each data that will be crated and finally stored
                t = str(utime.time())
                common.common_var.string_sent_to_epidemic = str_data +':'+ t
                #print(common.common_var.string_sent_to_epidemic)
            else:
                print('synching in progress')
            time.sleep(10)
            common.common_var.lock_LoRa_ND.release()
