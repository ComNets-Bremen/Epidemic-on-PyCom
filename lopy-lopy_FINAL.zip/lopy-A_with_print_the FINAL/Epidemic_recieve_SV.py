import time
import common
import utime

#SV = "SV:source:destination:FS:N:N:13-33-23"
def Time_conversion(seconds):
    seconds = seconds % (24 * 3600)
    hour = seconds // 3600
    seconds %= 3600
    minutes = seconds // 60
    seconds %= 60

    return ("%d:%02d:%02d" % (hour, minutes, seconds))
def rxred_SV():
    while True:
        with common.common_var.lock_LoRa_ND:
            if len(common.common_var.time_list) >0:
                if len(common.common_var.Rxr_SV) >0:
                    tt =utime.localtime()
                    current_time1=utime.mktime(tt)
                    sync_time = str(int(current_time1) - int(common.common_var.difference))
                    sync_time1=int(sync_time)

                    #common.print_str('recieved SV {0}--------{1}'.format(common.common_var.Rxr_SV.decode("utf-8"),sync_time))
                    recieved_sv_split = common.common_var.Rxr_SV.decode("utf-8").split(':') #this is the recieved total SV packet splitted

                    if recieved_sv_split[2] == common.common_var.str_add:
                        common.print_str("{0}  {1}  Epedemic  S  received SV  {2}".format(Time_conversion(sync_time1),common.common_var.str_add,common.common_var.Rxr_SV.decode("utf-8")))
                        Recieved_SV_list = recieved_sv_split[-1].split('-') #list of indexes recieved
                        own_SV = common.common_var.SV_list
                        list_of_wanted_data = list(set(Recieved_SV_list) - set(own_SV))
                        string1='-'.join(list_of_wanted_data)
                        common.common_var.sending=recieved_sv_split[1]+':'+recieved_sv_split[3]+':'+string1
                        #common.print_str('recieved SV: {} {}'.format(list_of_wanted_data, common.common_var.sync_time))

                        #else:
                        #    pass        #print(common.common_var.wanted)
                    else:
                        pass
                        #common.print_str("no data is required {}".format(common.common_var.sync_time))

                else:
                    pass
                common.common_var.Rxr_SV=''
            else:
                print('synching in progress')

            common.common_var.lock_LoRa_ND.release()
            time.sleep(6)
