#!/usr/bin/env python
#
# Copyright (c) 2019, Pycom Limited.
#
# This software is licensed under the GNU GPL version 3 or any
# later version, with permitted additional terms. For more information
# see the Pycom Licence v1.0 document supplied with this file, or
# available at https://www.pycom.io/opensource/licensing
#

from network import LoRa
import socket
import time
import ubinascii
import common

lora = LoRa(mode=LoRa.LORA, region=LoRa.EU868)
s = socket.socket(socket.AF_LORA, socket.SOCK_RAW)
s.setblocking(True)

def Lora_rxr_data():
    while True:
        with common.common_var.lock_LoRa_ND:
            data = s.recv(64)
            #common.print_str(data) #check this
            if len(data)>0: #check this
                a = data.decode('utf-8').split(':')

                if a[0]=='H':
                    common.common_var.Rxr_hello=data

                elif a[0] == 'SV':
                    common.common_var.Rxr_SV=data

                elif a[0]=='R':
                    common.common_var.Rxr_request=data

                elif a[0] == 'D':
                    
                    common.common_var.Rxr_data=data


                else:
                    pass

                common.common_var.lock_LoRa_ND.release()
                time.sleep(1)
